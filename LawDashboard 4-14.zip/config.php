<?php

define("SYSTEM_PATH_BACKEND", "http://localhost/LawDashboard/");
        
    ?>